cd listings
/home/cheriworker/cheri/output/morello-sdk/bin/clang -o libbumpall.so -shared -fPIC ./bump_alloc1.c
cd -
